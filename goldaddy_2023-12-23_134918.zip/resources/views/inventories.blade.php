{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('quantities', 'Quantities:') !!}
			{!! Form::text('quantities') !!}
		</li>
		<li>
			{!! Form::label('gold_id', 'Gold_id:') !!}
			{!! Form::text('gold_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}