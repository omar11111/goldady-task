<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateInventoriesTable extends Migration {

	public function up()
	{
		Schema::create('inventories', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('quantities');
			$table->integer('gold_id')->unsigned();
		});
	}

	public function down()
	{
		Schema::drop('inventories');
	}
}