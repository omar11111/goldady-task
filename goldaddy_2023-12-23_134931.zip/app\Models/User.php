<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model 
{

    protected $table = 'users';
    public $timestamps = true;
    protected $fillable = array('name', 'email');

    public function addresses()
    {
        return $this->hasMany('App\Models\Address');
    }

    public function transactions()
    {
        return $this->hasMany('App\Models\Transaction');
    }

}