<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GoldTransaction extends Model 
{

    protected $table = 'gold_transction';
    public $timestamps = true;

}